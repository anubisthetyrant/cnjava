import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;

public class rmiregistry {

    public static void main(String[] args) {
        try {
            // Start the RMI registry on default port (1099)
            Registry registry = LocateRegistry.createRegistry(1099);

            System.out.println("RMI Registry started on port 1099");

            // Keep the program running
            while (true) {
                // Add a delay (sleep) to avoid high CPU usage
                Thread.sleep(1000); // Sleep for 1 second
            }

        } catch (Exception e) {
            System.err.println("Exception occurred while starting RMI Registry: " + e.getMessage());
        }
    }
}

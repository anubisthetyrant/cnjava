import java.io.*;
import java.net.*;

class Filereceiver {

    public static void main(String args[]) throws IOException {
        Socket s = new Socket("127.0.0.1", 7777);
        if (s.isConnected()) {

            System.out.println("This program is done by ADWIN PAULJI 211211101006");
            System.out.println("connected to server");
        }

        FileOutputStream fout = new FileOutputStream(
                "C:\\Users\\Adwin Paulji\\Downloads\\My\\Java\\Learning\\receive.txt");
        DataInputStream din = new DataInputStream(s.getInputStream());
        int r;
        while ((r = din.read()) != -1) {

            fout.write((char) r);

        }

        s.close();
        fout.close();

    }

}

import javax.comm.*;

import java.io.*;

public class Rs232c {
    public static void main(String arg[]) {
        try {
            CommPortIdentifier ports = CommPortIdentifier.getPortIdentifier("COM3");
            SerialPort port = (SerialPort) ports.open("RS232C", 1000);
            port.setSerialPortParams(9600, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
            port.setFlowControlMode(SerialPort.FLOWCONTROL_NONE);
            OutputStream out = port.getOutputStream();

            String msg = "Transferred";
            out.write(msg.getBytes());
            out.flush();
            out.close();

            port.close();
        } catch (Exception e) {
            System.out.println("Error:" + e);

        }
    }
}
